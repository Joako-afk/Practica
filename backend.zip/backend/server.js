import app from "./app.js";

const PORT = process.env.PORT || 5000;

// Levanta el servidor sin imprimir mensaje en consola
app.listen(PORT);
