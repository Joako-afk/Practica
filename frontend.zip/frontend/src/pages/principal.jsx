import Board from "../components/tablero";

export default function Tablero() {
  return (
    <div className="p-6">
      <Board />
    </div>
  );
}
