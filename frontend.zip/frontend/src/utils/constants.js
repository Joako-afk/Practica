export const ESTADOS = [
  "Recibido",
  "En espera",
  "Ejecutando",
  "Finalizado",
];

export const PRIORIDADES = ["Urgente","Alta", "Mediana", "Baja"];

